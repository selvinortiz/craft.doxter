<?php
namespace Craft;

/**
 * Doxter 0.5.3
 *
 * Doxter is a markdown plugin designed to improve your workflow for writing docs
 *
 * @author		Selvin Ortiz - http://twitter.com/selvinortiz
 * @package		Doxter
 * @category	Markdown
 * @copyright	2014 Selvin Ortiz
 * @license		[MIT]
 */

class DoxterPlugin extends BasePlugin
{
	protected $devMode = true;

	public function init()
	{
		require_once craft()->path->getPluginsPath().'doxter/library/vendor/autoload.php';
	}

	/**
	 * Gets the plugin name or alias given by end user
	 *
	 * @param	bool	$real	Whether the real name should be returned
	 * @return	string
	 */
	public function getName($real=false)
	{
		if ($real)
		{
			return 'Doxter';
		}

		$alias = $this->getSettings()->pluginAlias;

		return empty($alias) ? 'Doxter' : Craft::t($alias);
	}

	public function getVersion()
	{
		return '0.5.3';
	}

	public function getDeveloper()
	{
		return 'Selvin Ortiz';
	}

	public function getDeveloperUrl()
	{
		return 'http://twitter.com/selvinortiz';
	}

	public function getDevMode()
	{
		if ($this->devMode)
		{
			if (false == is_readable(craft()->path->getPluginsPath().'doxter/resources/js/min/doxter.min.js'))
			{
				throw new Exception(Craft::t('Doxter is set to use source JS instead of production JS but source JS is missing.'));
			}

			return true;
		}

		return false;
	}

	public function hasCpSection()
	{
		return $this->getSettings()->enableCpTab;
	}

	public function defineSettings()
	{
		return array(
			'syntaxSnippet'		=> array(AttributeType::String, 'column'=>ColumnType::Text),
			'enableCpTab'		=> AttributeType::Bool,
			'pluginAlias'		=> AttributeType::String
		);
	}

	public function getSettingsHtml()
	{
		craft()->templates->includeCssResource('doxter/css/doxter.css');

		return craft()->templates->render(
			'doxter/_settings',
			array(
				'settings' => $this->getSettings()
			)
		);
	}

	public function addTwigExtension()
	{
		Craft::import('plugins.doxter.twigextensions.DoxterTwigExtension');

		return new DoxterTwigExtension();
	}

	public function onAfterInstall()
	{
		craft()->request->redirect(sprintf('/%s/settings/plugins/doxter', craft()->config->get('cpTrigger')));
	}
}
